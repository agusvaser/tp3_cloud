import boto3
import json
import uuid
import base64
import cgi
import io
import os

# Inicializa clientes
s3 = boto3.client('s3')
dynamodb = boto3.resource('dynamodb')
table = dynamodb.Table('TablaRecetas')

# Nombre del bucket de imágenes (reemplazar o pasar como variable de entorno)
BUCKET_IMAGENES = os.environ['BUCKET_IMAGENES']


def lambda_handler(event, context):
    # CORS
    cors_headers = {
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Headers': 'Content-Type',
        'Access-Control-Allow-Methods': 'OPTIONS,POST'
    }

    try:
        print("Received event:", json.dumps(event))

        # Respuesta para solicitud OPTIONS (CORS preflight)
        if event.get('httpMethod', '') == 'OPTIONS':
            return {
                'statusCode': 200,
                'headers': cors_headers,
                'body': json.dumps({'mensaje': 'Preflight CORS check'})
            }

        # Obtener el tipo de contenido del formulario enviado
        content_type = event['headers'].get('Content-Type') or event['headers'].get('content-type')

        # Decodificar si viene como base64 (común en API Gateway)
        if event.get("isBase64Encoded"):
            body = base64.b64decode(event["body"])
        else:
            body = event["body"].encode()

        # Parsear los datos del formulario multipart
        environ = {'REQUEST_METHOD': 'POST'}
        headers = {'content-type': content_type}
        fs = cgi.FieldStorage(fp=io.BytesIO(body), environ=environ, headers=headers)

        # Obtener campos del formulario
        nombre = fs.getvalue("nombre")
        ingredientes = fs.getvalue("ingredientes")
        instrucciones = fs.getvalue("instrucciones")
        categoria = fs.getvalue("categoria")
        tiempo = fs.getvalue("tiempo")
        usuario_email = fs.getvalue("usuario_email")

        # Validación básica
        if not all([nombre, ingredientes, instrucciones, categoria, tiempo, usuario_email]):
            return {
                'statusCode': 400,
                'headers': cors_headers,
                'body': json.dumps({'mensaje': 'Faltan datos para guardar la receta'})
            }

        # Generar un ID único para la receta
        id_receta = str(uuid.uuid4())
        imagen_url = None  # Inicializar como None por si no se sube imagen

        # SUBIR IMAGEN A S3 (si se incluyó una imagen en el formulario)
        if "imagen" in fs and fs["imagen"].filename:
            imagen_file = fs["imagen"]  # objeto tipo FieldStorage
            extension = os.path.splitext(imagen_file.filename)[1]  # obtener extensión: .jpg, .png, etc.
            key = f"{id_receta}{extension}"  # usar el ID de receta como nombre del archivo
            
            # Subida del archivo al bucket S3
            s3.upload_fileobj(
                imagen_file.file,        # contenido del archivo
                BUCKET_IMAGENES,         # nombre del bucket
                key,                     # clave (nombre del archivo en el bucket)
                ExtraArgs={
                    "ContentType": imagen_file.type,
                    "ACL": "public-read"  # necesario para que sea accesible públicamente
                }
            )

            # CREAR URL PÚBLICA de la imagen y guardarla en DynamoDB
            imagen_url = f"http://{BUCKET_IMAGENES}.s3.amazonaws.com/{key}"

        # Crear el ítem a guardar en DynamoDB
        item = {
            'USER': usuario_email,
            'RECETA': id_receta,
            'nombre': nombre,
            'ingredientes': ingredientes,
            'instrucciones': instrucciones,
            'categoria': categoria,
            'tiempo': tiempo
        }

        # Agregar URL de imagen si existe
        if imagen_url:
            item['imagen'] = imagen_url

        # GUARDAR EN DYNAMODB
        table.put_item(Item=item)

        # Respuesta exitosa
        return {
            'statusCode': 201,
            'headers': cors_headers,
            'body': json.dumps({'mensaje': 'Receta guardada correctamente', 'id_receta': id_receta})
        }

    except Exception as e:
        print("Error:", str(e))
        return {
            'statusCode': 500,
            'headers': cors_headers,
            'body': json.dumps({'error': str(e)})
        }
